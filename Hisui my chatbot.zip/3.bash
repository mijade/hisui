git add .
git commit -m "Initial commit"
