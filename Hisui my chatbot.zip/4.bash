git remote add origin <repository_url>
git branch -M main
git push -u origin main
